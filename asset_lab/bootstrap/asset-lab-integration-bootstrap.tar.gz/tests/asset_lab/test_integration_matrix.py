from pathlib import Path
import subprocess

from tools.asset_lab.build_integration_matrix import build_integration_matrix

ROOT = Path(__file__).resolve().parents[2]
AUTHORITY = ROOT / "asset_lab" / "source_authority"
BRANCH = "work/bahrain-brick-complete-asset-system-v1"


def _manifest_from_bundle(tmp_path: Path) -> Path:
    checkout = tmp_path / "asset-authority"
    subprocess.run(
        ["git", "clone", "-q", str(AUTHORITY / "bahrain-brick-assets-phase5-asset-lab.bundle"), str(checkout)],
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(checkout), "checkout", "-q", "-b", BRANCH, f"origin/{BRANCH}"],
        check=True,
    )
    return checkout / "docs" / "assets" / "ASSET_MASTER_MANIFEST.csv"


def test_all_98_records_are_accounted_for(tmp_path: Path) -> None:
    records = build_integration_matrix(_manifest_from_bundle(tmp_path))
    assert len(records) == 98
    assert len({record["asset_id"] for record in records}) == 98
    assert all(record["source_commit"] == "84ac94399262f71f29bf65dd553cd7729d87cce0" for record in records)
    assert all(record["destination_path"] or record["final_integration_state"] == "BLOCKED" for record in records)
    assert all(record["final_integration_state"] in {
        "INTEGRATED_RUNTIME",
        "INTEGRATED_PIPELINE",
        "INTEGRATED_SOURCE_MASTER",
        "INTEGRATED_CANONICALIZED",
        "BLOCKED",
    } for record in records)


def test_current_authority_is_fail_closed_until_license_and_runtime_derivatives_exist(tmp_path: Path) -> None:
    records = build_integration_matrix(_manifest_from_bundle(tmp_path))
    pending_license = [r for r in records if r["license"] == "PROJECT_OWNED_PENDING"]
    quarantined = [r for r in records if r["license"] == "QUARANTINED"]
    generator_only = [r for r in records if r["license"] == "Original project asset"]

    assert len(pending_license) == 81
    assert len(quarantined) == 8
    assert len(generator_only) == 9
    assert all(r["final_integration_state"] == "BLOCKED" for r in records)
    assert all(r["rejection_or_blocker_reason"] for r in records)
