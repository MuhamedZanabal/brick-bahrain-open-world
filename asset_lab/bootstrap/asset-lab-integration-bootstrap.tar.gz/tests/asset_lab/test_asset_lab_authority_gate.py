from pathlib import Path

import pytest

from tools.asset_lab.verify_asset_lab_authority import (
    AuthorityExpectations,
    verify_asset_lab_authority,
)

ROOT = Path(__file__).resolve().parents[2]
AUTHORITY = ROOT / "asset_lab" / "source_authority"


def test_verified_bundle_matches_frozen_authority(tmp_path: Path) -> None:
    result = verify_asset_lab_authority(
        bundle_path=AUTHORITY / "bahrain-brick-assets-phase5-asset-lab.bundle",
        summary_path=AUTHORITY / "bahrain-brick-assets-phase5-asset-lab-summary.json",
        work_dir=tmp_path,
        expectations=AuthorityExpectations(
            branch="work/bahrain-brick-complete-asset-system-v1",
            head="84ac94399262f71f29bf65dd553cd7729d87cce0",
            bundle_sha256="98e3964a1c84200c8d764116bc027678de0019fc6481ca41825ed606aa2a9c41",
            bundle_size=623404,
            commit_count=21,
            tracked_files=160,
            asset_records=98,
        ),
    )

    assert result.authority_verified is True
    assert result.actual_head == "84ac94399262f71f29bf65dd553cd7729d87cce0"
    assert result.commit_count == 21
    assert result.tracked_files == 160
    assert result.asset_records == 98
    assert result.original_checksum_mismatches == 11
    assert result.original_checksum_untracked_entries == 29
    assert len(result.actual_tracked_sha256) == 160


def test_wrong_bundle_hash_is_rejected(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="bundle SHA-256 mismatch"):
        verify_asset_lab_authority(
            bundle_path=AUTHORITY / "bahrain-brick-assets-phase5-asset-lab.bundle",
            summary_path=AUTHORITY / "bahrain-brick-assets-phase5-asset-lab-summary.json",
            work_dir=tmp_path,
            expectations=AuthorityExpectations(
                branch="work/bahrain-brick-complete-asset-system-v1",
                head="84ac94399262f71f29bf65dd553cd7729d87cce0",
                bundle_sha256="0" * 64,
                bundle_size=623404,
                commit_count=21,
                tracked_files=160,
                asset_records=98,
            ),
        )
