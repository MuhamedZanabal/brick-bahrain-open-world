# Bahrain Brick Complete Asset Lab Integration Design

## Objective

Integrate the complete verified Asset Lab authority into Bahrain Brick without altering the frozen premium baseline or protected controls. Every one of the 98 manifest records must be traceable from source authority through license gate, runtime derivative, Godot import, real-world usage, profile optimization, test evidence and final packaging.

## Architecture

The integration is split into five fail-closed layers:

1. **Authority layer:** immutable Git bundle, summary, expected head and independent 160-file hash ledger.
2. **Record layer:** 98-row integration matrix with source, license, conversion, destination, usage and evidence fields.
3. **Production layer:** pinned Blender generators and source masters produce deterministic GLBs and Low/Balanced/High variants.
4. **Runtime layer:** a dedicated Asset Lab district builder references optimized resources from the real `world.tscn` and existing road/traffic/NPC systems.
5. **Validation layer:** authority, license, import, orphan, usage, protected controls, regression, evidence and Android export gates.

## Data flow

The CI job verifies the bundled Git history, checks out head `84ac943...`, regenerates the matrix, and refuses runtime generation for any record without closed licensing. Cleared records are generated into a staging directory, inspected against mobile budgets, copied into canonical game paths, imported by Godot, and referenced by usage manifests consumed by the real world builder.

## Safety boundaries

- Game base is `e26ec912...` only.
- PR #55 and its branch are immutable.
- Protected-control files and expectations are never modified.
- Quarantined or pending-license records never enter exported runtime packages.
- Existing functional systems are retained when new visual assets are introduced.
- No production release or signing occurs in this phase.

## Acceptance

Completion requires 98/98 records in one of the authorized final states, zero silent omissions, zero unexplained blockers, zero broken references, protected controls 25/25, controls 28/28, all existing suites green, integrated runtime evidence, Android export and artifact checksums.
