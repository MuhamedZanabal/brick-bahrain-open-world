# Bahrain Brick Complete Asset Lab Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Account for and integrate all 98 Asset Lab records into the Bahrain Brick production pipeline and real Godot world while preserving protected gameplay and producing a verified Android QA APK.

**Architecture:** Freeze the exact Git bundle as source authority, enforce a license-first matrix, generate deterministic mobile GLBs with a pinned Blender toolchain, integrate them through an Asset Lab world builder and usage manifest, then run all existing and new validation gates. Runtime generation and export remain fail-closed while any record lacks lawful provenance or a validated derivative.

**Tech Stack:** GitHub Actions, Python 3.11+, Blender Python, Godot 4.3 GL Compatibility, GDScript, Android SDK/build tools, CSV/JSON evidence.

## Global Constraints

- Game base: `e26ec912db5c10d071a8e120010bdb5a9a136f17`.
- Asset source: `84ac94399262f71f29bf65dd553cd7729d87cce0` from bundle SHA-256 `98e3964a1c84200c8d764116bc027678de0019fc6481ca41825ed606aa2a9c41`.
- Integration branch: `work/bahrain-brick-asset-lab-integration-v1`.
- PR #55, premium branch and verified APK are immutable.
- Manifest count remains exactly 98.
- Protected controls remain 25/25 and controls regression remains 28/28.
- No production signing, merge to main or production release.

---

### Task 1: Freeze and verify cross-repository authority

**Files:**
- Create: `asset_lab/source_authority/bahrain-brick-assets-phase5-asset-lab.bundle`
- Create: `asset_lab/source_authority/bahrain-brick-assets-phase5-asset-lab-summary.json`
- Create: `tools/asset_lab/verify_asset_lab_authority.py`
- Test: `tests/asset_lab/test_asset_lab_authority_gate.py`

**Interfaces:**
- Consumes: exact bundle and summary.
- Produces: `ASSET_LAB_AUTHORITY_REPORT.json` and `ASSET_LAB_HEAD_TRACKED_SHA256SUMS.txt`.

- [x] Write failing authority tests for bundle hash/head/counts and stale source ledger detection.
- [x] Run tests and confirm missing-module failure.
- [x] Implement bundle verification, isolated checkout, record counting and independent tracked-file hashing.
- [x] Run focused tests; expected `4 passed` with matrix tests included.
- [ ] Commit authority files and evidence to the integration branch.

### Task 2: Enforce complete 98-record accounting

**Files:**
- Create: `tools/asset_lab/build_integration_matrix.py`
- Create: `docs/asset_lab/ASSET_LAB_INTEGRATION_MATRIX.csv`
- Create: `docs/asset_lab/ASSET_LAB_INTEGRATION_MATRIX.json`
- Test: `tests/asset_lab/test_integration_matrix.py`

**Interfaces:**
- Consumes: `ASSET_MASTER_MANIFEST.csv` from the verified bundle checkout.
- Produces: exactly 98 unique records with allowed final states and explicit blockers.

- [x] Write failing matrix tests for 98 unique records and fail-closed licensing/runtime status.
- [x] Implement deterministic record/source hashes, source mapping and destination mapping.
- [x] Generate CSV and JSON ledgers.
- [x] Verify 81 pending-license, 8 quarantined and 9 generator-only records.
- [ ] Add CI comparison that rejects count reduction or silent omissions.

### Task 3: Close licensing and provenance

**Files:**
- Create: `docs/asset_lab/LICENSE_DECISIONS.csv`
- Create: `docs/asset_lab/ATTRIBUTION.md`
- Create: `tools/asset_lab/validate_license_gate.py`
- Test: `tests/asset_lab/test_license_gate.py`

**Interfaces:**
- Consumes: integration matrix and source license files.
- Produces: an allow/deny decision for every record.

- [ ] Write tests that reject `PROJECT_OWNED_PENDING`, `QUARANTINED`, blank licenses and missing attribution.
- [ ] Record explicit project-owned distribution terms for 81 records after owner authorization.
- [ ] Resolve or replace all eight quarantined groups with exact upstream provenance.
- [ ] Run license gate; expected `98 allowed, 0 blocked` before runtime generation.

### Task 4: Pin Blender and generate runtime derivatives

**Files:**
- Create: `tools/asset_lab/generate_runtime_assets.py`
- Create: `tools/asset_lab/generators/generate_architecture_kits.py`
- Create: `tools/asset_lab/generators/generate_commercial_props.py`
- Create: `.github/workflows/generate_asset_lab_runtime.yml`
- Test: `tests/asset_lab/test_runtime_generation_contract.py`

**Interfaces:**
- Consumes: cleared matrix records, source specs and existing Blender generators.
- Produces: canonical GLBs, generation report and runtime SHA-256 values.

- [ ] Write contract tests requiring one GLB and one report entry per cleared runtime record.
- [ ] Pin a Blender version and verify its downloaded archive SHA-256.
- [ ] Execute existing generators for records 75-98.
- [ ] Implement missing deterministic generators for villa, traditional, souq and waterfront records.
- [ ] Reject zero-sized meshes, missing materials, invalid normals, excessive dimensions and missing collisions.
- [ ] Preserve source masters separately from optimized derivatives.

### Task 5: Produce Low/Balanced/High mobile variants

**Files:**
- Create: `tools/asset_lab/optimize_runtime_assets.py`
- Create: `docs/asset_lab/MOBILE_BUDGET_REPORT.json`
- Test: `tests/asset_lab/test_mobile_budgets.py`

**Interfaces:**
- Consumes: generated canonical GLBs.
- Produces: profile variants and budget decisions.

- [ ] Write tests for triangle, material, texture, collision, shadow and visibility budgets.
- [ ] Generate LOD and simplified collision variants.
- [ ] Assign profile-specific instance density and visibility ranges.
- [ ] Fail the build on unapproved budget exceedance.

### Task 6: Integrate resources into the real Godot world

**Files:**
- Create: `scripts/asset_lab/asset_lab_registry.gd`
- Create: `scripts/asset_lab/asset_lab_world_builder.gd`
- Create: `assets/asset_lab/usage_manifest.json`
- Modify: `scenes/world.tscn`
- Modify: `scripts/hero_district_builder.gd`
- Test: `tests/asset_lab_acceptance_test.gd`

**Interfaces:**
- Consumes: optimized GLBs and profile assignments.
- Produces: district placements, usage references and runtime evidence hooks.

- [ ] Write failing Godot tests for manifest load, resource existence, district nodes and nonzero usage counts.
- [ ] Add an isolated `AssetLab` node under the real world scene without touching protected input/controller code.
- [ ] Place architecture by district and connect roads/props to existing builders.
- [ ] Record scene path, node path, UID, spawn rule, profile behavior and instance count per runtime record.
- [ ] Reject unreferenced runtime assets and broken paths.

### Task 7: Add complete Asset Lab acceptance gates

**Files:**
- Create: `tests/asset_lab_acceptance_test.gd`
- Create: `scenes/asset_lab_acceptance_test.tscn`
- Create: `tools/asset_lab/scan_runtime_usage.py`
- Modify: canonical validation runner fragments only outside protected-control sources.

**Interfaces:**
- Consumes: integration matrix, usage manifest and Godot project.
- Produces: acceptance log with exact configured count.

- [ ] Verify authority, 98/98 accounting, hashes, licenses, imports, paths, UIDs, usage, profiles and Android inclusion.
- [ ] Run protected controls before tests, after tests, after export and after packaging.
- [ ] Run all existing suites with unchanged expected counts.
- [ ] Require zero unresolved critical runtime errors.

### Task 8: Capture equivalent visual and performance evidence

**Files:**
- Create: `tools/asset_lab/capture_asset_lab_evidence.sh`
- Create: `docs/asset_lab/evidence/COMPARISON_REPORT.json`

**Interfaces:**
- Consumes: frozen before build and integrated after build.
- Produces: equivalent screenshots, contact sheet, startup/gameplay videos and performance comparison.

- [ ] Lock camera, orientation, FOV, time, profile and resolution.
- [ ] Capture all required before/after views and every asset family.
- [ ] Record APK-size growth, load duration and instrumented metrics only where a real tool supplies them.
- [ ] Mark emulator and physical-device status explicitly.

### Task 9: Export, inspect and package v14.0.5 QA

**Files:**
- Modify: `project.godot` and `export_presets.cfg` only for version/package metadata outside protected controls.
- Create: packaging/checksum reports.

**Interfaces:**
- Consumes: fully validated integrated project.
- Produces: `bahrain_brick_v14.0.5-asset-lab-qa.apk` and all required artifacts.

- [ ] Export version name `1.4.0.5-asset-lab-qa`, code `1405`, package `com.bahrainbrick.game.qa`, label `Bahrain Brick`, orientation `sensorLandscape`.
- [ ] Verify ZIP integrity, metadata, ABIs, debug QA signing, alignment and contained resources.
- [ ] Create source, source-master, runtime, license, logs and evidence packages with SHA-256 files.
- [ ] Create a separate validation branch and draft PR back to the integration branch.
- [ ] Do not merge or publish a production release.
