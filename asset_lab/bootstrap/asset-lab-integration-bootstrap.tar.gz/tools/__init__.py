"""Bahrain Brick build and validation tools."""
