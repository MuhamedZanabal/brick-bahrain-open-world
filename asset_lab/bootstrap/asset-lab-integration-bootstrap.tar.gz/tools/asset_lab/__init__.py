"""Asset Lab authority and integration tooling."""
