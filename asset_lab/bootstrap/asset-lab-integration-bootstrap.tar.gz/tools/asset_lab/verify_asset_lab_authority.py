from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class AuthorityExpectations:
    branch: str
    head: str
    bundle_sha256: str
    bundle_size: int
    commit_count: int
    tracked_files: int
    asset_records: int


@dataclass(frozen=True)
class AuthorityResult:
    authority_verified: bool
    actual_head: str
    commit_count: int
    tracked_files: int
    asset_records: int
    bundle_sha256: str
    bundle_size: int
    original_checksum_mismatches: int
    original_checksum_untracked_entries: int
    actual_tracked_sha256: Mapping[str, str]


def _run(*args: str, cwd: Path | None = None) -> str:
    completed = subprocess.run(
        list(args),
        cwd=cwd,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return completed.stdout.strip()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _tracked_hashes(checkout: Path) -> dict[str, str]:
    raw = subprocess.run(
        ["git", "ls-files", "-z"],
        cwd=checkout,
        check=True,
        stdout=subprocess.PIPE,
    ).stdout
    paths = [item.decode("utf-8") for item in raw.split(b"\0") if item]
    return {path: _sha256(checkout / path) for path in sorted(paths)}


def _audit_original_checksums(
    checkout: Path,
    tracked_hashes: Mapping[str, str],
) -> tuple[int, int]:
    checksum_path = checkout / "SHA256SUMS"
    mismatches = 0
    untracked = 0
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, rel = line.split(None, 1)
        rel = rel.strip().lstrip("*")
        if rel not in tracked_hashes:
            untracked += 1
            continue
        if tracked_hashes[rel] != expected:
            mismatches += 1
    return mismatches, untracked


def verify_asset_lab_authority(
    *,
    bundle_path: Path,
    summary_path: Path,
    work_dir: Path,
    expectations: AuthorityExpectations,
) -> AuthorityResult:
    bundle_path = bundle_path.resolve()
    summary_path = summary_path.resolve()
    work_dir = work_dir.resolve()

    actual_size = bundle_path.stat().st_size
    if actual_size != expectations.bundle_size:
        raise ValueError(
            f"bundle size mismatch: expected {expectations.bundle_size}, got {actual_size}"
        )

    actual_sha = _sha256(bundle_path)
    if actual_sha != expectations.bundle_sha256:
        raise ValueError(
            f"bundle SHA-256 mismatch: expected {expectations.bundle_sha256}, got {actual_sha}"
        )

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary_checks = {
        "branch": expectations.branch,
        "head": expectations.head,
        "commit_count": expectations.commit_count,
        "tracked_files": expectations.tracked_files,
        "asset_records": expectations.asset_records,
    }
    for key, expected in summary_checks.items():
        if summary.get(key) != expected:
            raise ValueError(
                f"summary {key} mismatch: expected {expected!r}, got {summary.get(key)!r}"
            )
    bundle_summary = summary.get("bundle", {})
    if bundle_summary.get("bytes") != expectations.bundle_size:
        raise ValueError("summary bundle size does not match authority")
    if bundle_summary.get("sha256") != expectations.bundle_sha256:
        raise ValueError("summary bundle SHA-256 does not match authority")

    verify_repo = work_dir / "bundle-verify"
    verify_repo.mkdir(parents=True, exist_ok=True)
    _run("git", "init", "-q", str(verify_repo), cwd=work_dir)
    _run("git", "bundle", "verify", str(bundle_path), cwd=verify_repo)
    heads = _run("git", "bundle", "list-heads", str(bundle_path), cwd=verify_repo)
    expected_head_line = f"{expectations.head} refs/heads/{expectations.branch}"
    if expected_head_line not in heads.splitlines():
        raise ValueError(f"bundle does not expose expected head: {expected_head_line}")

    checkout = work_dir / "asset-authority"
    if checkout.exists():
        shutil.rmtree(checkout)
    _run("git", "clone", "-q", str(bundle_path), str(checkout), cwd=work_dir)
    _run(
        "git",
        "-C",
        str(checkout),
        "checkout",
        "-q",
        "-b",
        expectations.branch,
        f"origin/{expectations.branch}",
        cwd=work_dir,
    )

    actual_head = _run("git", "rev-parse", "HEAD", cwd=checkout)
    if actual_head != expectations.head:
        raise ValueError(f"head mismatch: expected {expectations.head}, got {actual_head}")

    commit_count = int(_run("git", "rev-list", "--count", "HEAD", cwd=checkout))
    if commit_count != expectations.commit_count:
        raise ValueError(
            f"commit count mismatch: expected {expectations.commit_count}, got {commit_count}"
        )

    tracked_hashes = _tracked_hashes(checkout)
    if len(tracked_hashes) != expectations.tracked_files:
        raise ValueError(
            f"tracked file count mismatch: expected {expectations.tracked_files}, got {len(tracked_hashes)}"
        )

    manifest = checkout / "docs" / "assets" / "ASSET_MASTER_MANIFEST.csv"
    with manifest.open(newline="", encoding="utf-8-sig") as handle:
        asset_records = sum(1 for _ in csv.DictReader(handle))
    if asset_records != expectations.asset_records:
        raise ValueError(
            f"asset record count mismatch: expected {expectations.asset_records}, got {asset_records}"
        )

    checksum_mismatches, checksum_untracked = _audit_original_checksums(
        checkout, tracked_hashes
    )

    return AuthorityResult(
        authority_verified=True,
        actual_head=actual_head,
        commit_count=commit_count,
        tracked_files=len(tracked_hashes),
        asset_records=asset_records,
        bundle_sha256=actual_sha,
        bundle_size=actual_size,
        original_checksum_mismatches=checksum_mismatches,
        original_checksum_untracked_entries=checksum_untracked,
        actual_tracked_sha256=tracked_hashes,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--ledger", type=Path, required=True)
    args = parser.parse_args()

    result = verify_asset_lab_authority(
        bundle_path=args.bundle,
        summary_path=args.summary,
        work_dir=args.work_dir,
        expectations=AuthorityExpectations(
            branch="work/bahrain-brick-complete-asset-system-v1",
            head="84ac94399262f71f29bf65dd553cd7729d87cce0",
            bundle_sha256="98e3964a1c84200c8d764116bc027678de0019fc6481ca41825ed606aa2a9c41",
            bundle_size=623404,
            commit_count=21,
            tracked_files=160,
            asset_records=98,
        ),
    )
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(asdict(result), indent=2) + "\n", encoding="utf-8")
    args.ledger.parent.mkdir(parents=True, exist_ok=True)
    args.ledger.write_text(
        "".join(
            f"{digest}  {path}\n"
            for path, digest in sorted(result.actual_tracked_sha256.items())
        ),
        encoding="utf-8",
    )
    print(f"Asset Lab authority verified: {result.asset_records}/98 records")
    print(
        "Original SHA256SUMS defects: "
        f"{result.original_checksum_mismatches} tracked mismatches, "
        f"{result.original_checksum_untracked_entries} untracked entries"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
