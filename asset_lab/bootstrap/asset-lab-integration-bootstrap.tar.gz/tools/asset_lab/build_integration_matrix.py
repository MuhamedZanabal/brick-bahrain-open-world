from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Iterable

SOURCE_REPOSITORY = "MuhamedZanabal/Bahrain_bricks_Assets"
SOURCE_COMMIT = "84ac94399262f71f29bf65dd553cd7729d87cce0"
ALLOWED_STATES = {
    "INTEGRATED_RUNTIME",
    "INTEGRATED_PIPELINE",
    "INTEGRATED_SOURCE_MASTER",
    "INTEGRATED_CANONICALIZED",
    "BLOCKED",
}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _record_hash(row: dict[str, str]) -> str:
    payload = json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _source_paths(row: dict[str, str]) -> tuple[str, str]:
    category = row["category"]
    sub = row["subcategory"]
    asset_id = row["asset_id"]

    if category == "architecture" and sub in {"villas", "traditional", "souq", "waterfront"}:
        slug = "villa" if sub == "villas" else sub
        return (
            f"docs/assets/specs/{slug}_kit.md",
            f"docs/assets/concepts/bh_arch_{slug}_kit_concept.svg",
        )
    if category == "third_party_quarantine":
        return ("docs/assets/THIRD_PARTY_ASSETS.csv", "docs/assets/SOURCE_AUTHORITY_AUDIT.md")

    exact_generators = {
        "bh_road_two_lane_straight_20m_01": "tools/blender/generate_road_module.py",
        "bh_kerb_standard_straight_4m_01": "tools/blender/generate_kerb_module.py",
        "bh_prop_street_bollard_a_01": "tools/blender/generate_bollard.py",
        "bh_prop_streetlamp_prom_a_01": "tools/blender/generate_streetlamp.py",
        "bh_supermarket_storefront_a_01": "tools/blender/generate_shopfront_shell.py",
        "bh_supermarket_shelf_1m_01": "docs/assets/specs/supermarket_kit.md",
        "bh_cafe_storefront_karak_a_01": "tools/blender/generate_shopfront_shell.py",
        "bh_cafe_table_chair_set_a_01": "docs/assets/specs/cafe_restaurant_kit.md",
        "bh_road_intersection_four_way_20m_01": "tools/blender/generate_intersection_modules.py",
        "bh_road_intersection_t_20m_01": "tools/blender/generate_intersection_modules.py",
        "bh_road_roundabout_compact_24m_01": "tools/blender/generate_roundabout_module.py",
        "bh_road_crossing_zebra_8m_01": "tools/blender/generate_pedestrian_crossing.py",
        "bh_prop_traffic_signal_a_01": "tools/blender/generate_traffic_signal.py",
        "bh_prop_crash_barrier_4m_01": "tools/blender/generate_crash_barrier.py",
        "bh_prop_bus_shelter_a_01": "tools/blender/generate_bus_shelter.py",
        "bh_road_highway_six_lane_straight_40m_01": "tools/blender/generate_highway_modules.py",
        "bh_road_highway_curve_40m_01": "tools/blender/generate_highway_modules.py",
        "bh_road_highway_slip_road_30m_01": "tools/blender/generate_highway_modules.py",
        "bh_road_highway_exit_40m_01": "tools/blender/generate_highway_modules.py",
        "bh_sidewalk_commercial_straight_4m_01": "tools/blender/generate_sidewalk_modules.py",
        "bh_sidewalk_driveway_cut_4m_01": "tools/blender/generate_sidewalk_modules.py",
        "bh_drainage_channel_straight_4m_01": "tools/blender/generate_drainage_channel.py",
        "bh_prop_direction_sign_frame_a_01": "tools/blender/generate_direction_sign_frame.py",
        "bh_prop_supermarket_checkout_a_01": "tools/blender/generate_supermarket_checkout.py",
    }
    source = exact_generators.get(asset_id, "docs/assets/ASSET_MASTER_MANIFEST.csv")
    if "supermarket" in asset_id:
        master = "docs/assets/specs/supermarket_kit.md"
    elif "cafe" in asset_id:
        master = "docs/assets/specs/cafe_restaurant_kit.md"
    elif "highway" in asset_id or "sidewalk" in asset_id or "drainage" in asset_id:
        master = "docs/assets/specs/highway_sidewalk_kit.md"
    elif "intersection" in asset_id or "roundabout" in asset_id or "crossing" in asset_id or "traffic_signal" in asset_id or "bus_shelter" in asset_id:
        master = "docs/assets/specs/road_intersections_and_transit_kit.md"
    else:
        master = "docs/assets/specs/road_infrastructure_kit.md"
    return source, master


def _target_system(row: dict[str, str]) -> str:
    category, sub = row["category"], row["subcategory"]
    mapping = {
        ("architecture", "villas"): "scenes/world.tscn::AssetLab/VillaDistrict",
        ("architecture", "traditional"): "scenes/world.tscn::AssetLab/TraditionalDistrict",
        ("architecture", "souq"): "scenes/world.tscn::AssetLab/SouqDistrict",
        ("architecture", "waterfront"): "scenes/world.tscn::AssetLab/WaterfrontDistrict",
        ("architecture", "supermarket"): "scenes/world.tscn::AssetLab/CommercialDistrict",
        ("architecture", "restaurant"): "scenes/world.tscn::AssetLab/CommercialDistrict",
        ("roads", "geometry"): "scripts/hero_district_builder.gd::road_network",
        ("roads", "kerbs"): "scripts/hero_district_builder.gd::road_network",
        ("roads", "markings"): "scripts/hero_district_builder.gd::road_network",
        ("environment", "roads"): "scripts/hero_district_builder.gd::road_network",
        ("props", "street"): "scripts/hero_district_builder.gd::street_prop_spawner",
        ("props", "commercial"): "scenes/world.tscn::AssetLab/CommercialDistrict",
    }
    return mapping.get((category, sub), "asset_lab/source_authority::quarantine_only")


def _blocker(row: dict[str, str]) -> str:
    license_name = row["license"]
    if license_name == "QUARANTINED":
        return "Third-party provenance and redistribution license are unresolved; runtime use is prohibited."
    if license_name == "PROJECT_OWNED_PENDING":
        return "Project ownership/distribution license metadata is incomplete and the declared runtime GLB does not exist."
    return "Original procedural source exists, but no generated GLB, Godot 4.3 import evidence, or Android benchmark exists."


def build_integration_matrix(manifest_path: Path) -> list[dict[str, str]]:
    manifest_path = manifest_path.resolve()
    repo_root = manifest_path.parents[2]
    with manifest_path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))

    records: list[dict[str, str]] = []
    for row in rows:
        source_path, master_path = _source_paths(row)
        source_file = repo_root / source_path
        master_file = repo_root / master_path
        game_path = row["game_path"].strip()
        license_name = row["license"].strip()
        attribution = {
            "PROJECT_OWNED_PENDING": "Project-owned notice required; public distribution license not selected.",
            "Original project asset": "Preserve Bahrain Brick project ownership notice.",
            "QUARANTINED": "Unknown; do not redistribute or integrate until verified.",
        }[license_name]
        source_master_status = (
            "present_spec_or_generator" if source_file.exists() and master_file.exists() else "partial_source_record"
        )
        runtime_status = "quarantined_no_runtime_path" if not game_path else "declared_runtime_path_missing"
        record = {
            "asset_id": row["asset_id"],
            "source_repository": SOURCE_REPOSITORY,
            "source_commit": SOURCE_COMMIT,
            "source_path": source_path,
            "source_master_path": master_path,
            "asset_category": row["category"],
            "asset_subcategory": row["subcategory"],
            "file_type": row["original_format"],
            "record_metadata_sha256": _record_hash(row),
            "source_content_sha256": _sha256(source_file) if source_file.exists() else "",
            "source_master_sha256": _sha256(master_file) if master_file.exists() else "",
            "runtime_content_sha256": "",
            "license": license_name,
            "attribution_requirement": attribution,
            "source_master_status": source_master_status,
            "runtime_status": runtime_status,
            "godot_compatibility": "UNVERIFIED_NOT_IMPORTED",
            "intended_destination": game_path or "asset_lab/source_authority/quarantine",
            "destination_path": game_path,
            "target_scene_or_system": _target_system(row),
            "conversion_required": (
                "No conversion permitted until provenance clears"
                if license_name == "QUARANTINED"
                else "Generate/convert source specification to GLB, then import with Godot 4.3 GL Compatibility"
            ),
            "optimization_required": "Low/Balanced/High variants; enforce Android triangle, material, texture, shadow and visibility budgets",
            "collision_requirement": row["collision_type"],
            "lod_requirement": row["lod_count"],
            "material_requirement": f"{row['material_count']} materials; max texture {row['max_texture_resolution']}",
            "animation_requirement": "none declared",
            "audio_import_requirement": "not applicable",
            "quality_profile_low": "runtime derivative missing",
            "quality_profile_balanced": "runtime derivative missing",
            "quality_profile_high": "runtime derivative missing",
            "final_integration_state": "BLOCKED",
            "test_evidence": "Asset Lab unit tests 16/16; manifest validation 98; Godot runtime not run; Android benchmark not run",
            "rejection_or_blocker_reason": _blocker(row),
        }
        if record["final_integration_state"] not in ALLOWED_STATES:
            raise ValueError(f"invalid integration state for {row['asset_id']}")
        records.append(record)

    if len(records) != 98 or len({record["asset_id"] for record in records}) != 98:
        raise ValueError("integration matrix must account for exactly 98 unique records")
    return records


def write_matrix(records: Iterable[dict[str, str]], csv_path: Path, json_path: Path) -> None:
    records = list(records)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    records = build_integration_matrix(args.manifest)
    write_matrix(records, args.csv, args.json)
    print(f"Integration matrix written: {len(records)}/98 records")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
